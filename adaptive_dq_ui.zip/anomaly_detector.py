from sklearn.ensemble import IsolationForest

def detect_anomalies(df, features, contamination=0.05):
    model = IsolationForest(contamination=contamination, random_state=42)
    df["anomaly_score"] = model.fit_predict(df[features])
    return df[df["anomaly_score"] == -1]