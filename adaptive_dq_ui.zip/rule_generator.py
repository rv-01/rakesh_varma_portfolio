def generate_rule_from_anomalies(anomalies, column):
    return {
        "rule_type": "range_check",
        "column": column,
        "range": [anomalies[column].min(), anomalies[column].max()],
        "confidence": "low",
        "status": "suggested"
    }