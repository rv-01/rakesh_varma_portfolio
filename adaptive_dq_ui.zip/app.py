import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from profiler import generate_profile
from anomaly_detector import detect_anomalies
from rule_generator import generate_rule_from_anomalies
from feedback_loop import load_rules, save_rule
from monitor import apply_rules

st.set_page_config(page_title="Adaptive DQ Framework", layout="wide")

st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Home", "Data Upload & Profiling", "Anomaly Detection",
                                  "Adaptive Rules", "Data Validation"])

if page == "Home":
    st.title("Adaptive Data Quality Framework")
    st.markdown("""
        - **Upload Data**: Profile your data and detect anomalies.
        - **Generate Adaptive Rules**: Automatically derive rules from anomalies.
        - **Manage & Apply Rules**: Validate new data and improve quality continuously.
    """)

elif page == "Data Upload & Profiling":
    st.title("Data Upload & Profiling")
    uploaded_file = st.file_uploader("Upload CSV", type="csv")
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        st.success("Data uploaded successfully!")
        st.dataframe(df.head())
        if st.button("Generate Profiling Report"):
            generate_profile(df, "profile_report.html")
            with open("profile_report.html", "r") as f:
                st.components.v1.html(f.read(), height=600, scrolling=True)

elif page == "Anomaly Detection":
    st.title("Anomaly Detection")
    df = pd.read_csv("synthetic_customers.csv")
    numeric_cols = df.select_dtypes(include='number').columns.tolist()
    selected_cols = st.multiselect("Select columns", numeric_cols, default=numeric_cols)
    contamination = st.slider("Anomaly Sensitivity", 0.01, 0.1, 0.05)

    if st.button("Run Detection"):
        anomalies = detect_anomalies(df, selected_cols, contamination)
        st.warning(f"{len(anomalies)} anomalies found")
        st.dataframe(anomalies)
        if len(selected_cols) >= 2:
            fig, ax = plt.subplots()
            ax.scatter(df[selected_cols[0]], df[selected_cols[1]], alpha=0.5, label="Normal")
            ax.scatter(anomalies[selected_cols[0]], anomalies[selected_cols[1]], color='r', label="Anomaly")
            ax.legend()
            st.pyplot(fig)

elif page == "Adaptive Rules":
    st.title("Adaptive Rule Generation")
    df = pd.read_csv("synthetic_customers.csv")
    rules = load_rules()
    col = st.selectbox("Column to Generate Rule", df.select_dtypes(include='number').columns.tolist())
    anomalies = detect_anomalies(df, [col])
    rule = generate_rule_from_anomalies(anomalies, col)
    st.json(rule)
    if st.button("Approve Rule"):
        rule["status"] = "approved"
        save_rule(rule)
        st.success("Rule saved")

    st.subheader("Current Rules")
    st.dataframe(pd.DataFrame(rules))

elif page == "Data Validation":
    st.title("Data Validation")
    df = pd.read_csv("synthetic_customers.csv")
    rules = load_rules()
    if st.button("Validate Data"):
        violations = apply_rules(df, rules)
        if violations:
            for col, rows in violations:
                st.error(f"Violations in: {col}")
                st.dataframe(rows)
        else:
            st.success("No violations found")