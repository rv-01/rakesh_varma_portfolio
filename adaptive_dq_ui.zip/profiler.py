from pandas_profiling import ProfileReport

def generate_profile(df, output_path="profile_report.html"):
    profile = ProfileReport(df, title="Profiling Report", explorative=True)
    profile.to_file(output_path)