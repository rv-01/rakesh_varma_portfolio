def apply_rules(df, rules):
    violations = []
    for rule in rules:
        if rule["rule_type"] == "range_check":
            col = rule["column"]
            min_val, max_val = rule["range"]
            bad = df[(df[col] < min_val) | (df[col] > max_val)]
            if not bad.empty:
                violations.append((col, bad))
    return violations