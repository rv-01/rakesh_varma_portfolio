import yaml

def load_rules(file_path="rules.yaml"):
    try:
        with open(file_path) as f:
            return yaml.safe_load(f) or []
    except FileNotFoundError:
        return []

def save_rule(rule, file_path="rules.yaml"):
    rules = load_rules(file_path)
    rules.append(rule)
    with open(file_path, "w") as f:
        yaml.dump(rules, f)